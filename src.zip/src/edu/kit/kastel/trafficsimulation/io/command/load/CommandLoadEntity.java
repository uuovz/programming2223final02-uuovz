package edu.kit.kastel.trafficsimulation.io.command.load;

import edu.kit.kastel.trafficsimulation.io.SimulationFileLoader;
import edu.kit.kastel.trafficsimulation.simulator.Config;

import java.util.regex.Pattern;

public abstract class CommandLoadEntity {

    protected static final String EXCEPTION_TEMPLATE_ARGUMENT_AMOUNT = "Invalid argument amount in the %s dataset.";
    protected static final String EXCEPTION_TEMPLATE_DUPLICATED_ID = "Duplicated IDs in %s.";
    protected static final String EXCEPTION_TEMPLATE_INVALID_ID = "Invalid id in %s dataset";
    protected static final String EXCPETION_TEMPLATE_SYNTAX = "Line does not match regex %s";
    protected static final int INDEX_ID = 0;
    protected SimulationFileLoader simulationFileLoader;
    protected Config config;

    CommandLoadEntity(SimulationFileLoader simulationFileLoader, Config config) {
        this.simulationFileLoader = simulationFileLoader;
        this.config = config;
    }

    public abstract void load();

    protected static boolean checkSyntax(Pattern pattern, String input) {
        return pattern.matcher(input).matches();
    }

}
